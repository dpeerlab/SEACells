__version__ = "0.0.0"
__author__ = "Manu Setty, Zi-Ning Choo, Sitara Persad"
__author_email__ = "scp2152@columbia.edu"